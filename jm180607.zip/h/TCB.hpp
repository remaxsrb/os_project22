//
// Created by marko on 20.4.22..
//

#ifndef OS_PROJECT2022_TCB_HPP
#define OS_PROJECT2022_TCB_HPP


#include "../lib/hw.h"
#include "threadcodes.hpp"
#include "../lib/mem.h"
#include "syscall_cpp.hpp"
#include  "../h/Scheduler.hpp"


// Thread Control Block
class TCB
{
public:
    ~TCB() { delete[] stack; }

    uint8 getThreadStatus() const { return this->thread_status; }

    void setThreadStatus(uint8 status) { this->thread_status = status; }

    bool isSysThread() const {return  sysThread;}


    uint64 getTimeSlice() const { return timeSlice; }

    using Body = void (*)(void*);


    static thread_t createOutputThread();
    static thread_t createMainThread();
    static thread_t createIdleThread();

    int start();

    void *operator new(size_t size) { return __mem_alloc(size); }

    void operator delete(void *ptr) { __mem_free(ptr); }

    static void yield();

    static thread_t running;

    static thread_t output;

    static thread_t main;

    static thread_t idle; //receno je u postavci zadatka da treba imati idle nit kako scheduler nikada ne bi bio prazan

    sem_t spaceAvailable;

    sem_t itemAvailable;

    sem_t joinTimerSem;

    char* getMessage ();

    void setMessage (char* msg);

    void sync();

private:
    TCB(Body body, void *arg, uint64 *stack) :
            body(body),
            arg(arg),
            stack(body != nullptr ? stack : nullptr),
            context({ body!= nullptr ? (uint64) &threadWrapper : 0,
                     body != nullptr ? (uint64) &stack[DEFAULT_STACK_SIZE] : 0
                    }),
            timeSlice(DEFAULT_TIME_SLICE),
            thread_status(body!= nullptr ? CREATED : RUNNING),
            sysThread(false), waitingForPair(false){}

private:

    struct Context
    {
        uint64 ra;
        uint64 sp;
    };

    Body body;
    void* arg;
    uint64 *stack;
    Context context;
    uint64 timeSlice;
    volatile uint8 thread_status;

    bool sysThread; // fleg da svaka nit zna da li je sistemska ili nije

    int threadID;

    List<char*> messageQueue;

    thread_t pair;

    bool waitingForPair;

    friend class Riscv;

    friend class _sem;

    friend class SleepingThreads;

    static thread_t createThread( Body body,  void *arg, uint64 *stack);

    static void threadWrapper();

    static void contextSwitch(Context *oldContext, Context *runningContext);

    static void dispatch();

    static void join (thread_t* handle);

    static int sleep(time_t); //uspavljuje trenutnu nit na time_t otkucaja

     int wake(); //ne sme da bude staticna metoda jer je poziva objekat TCB u sleeping threads klasi pri budjenju niti

    static int exit(); //gasenje trenutne niti

    static uint64 timeSliceCounter;

    static void outputThreadBody(void*);

    static void idleThreadBody(void*);

    static int globalThreadId;

    static int getThreadID();

};


#endif //OS_PROJECT2022_TCB_HPP
